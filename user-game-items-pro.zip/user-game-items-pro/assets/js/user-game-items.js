document.addEventListener('DOMContentLoaded', () => {
  const createCustomSelect = (nativeSelect) => {
    if (!nativeSelect || nativeSelect.dataset.enhanced === '1') return;

    nativeSelect.dataset.enhanced = '1';
    nativeSelect.style.display = 'none';

    const wrapper = document.createElement('div');
    wrapper.className = 'ugip-custom-select';

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'ugip-custom-select-trigger';

    const list = document.createElement('ul');
    list.className = 'ugip-custom-select-list';

    const setValue = (value, label) => {
      nativeSelect.value = value;
      trigger.textContent = label;
      nativeSelect.dispatchEvent(new Event('change'));
      wrapper.classList.remove('is-open');

      list.querySelectorAll('li').forEach((li) => {
        li.classList.toggle('is-active', li.dataset.value === value);
      });
    };

    [...nativeSelect.options].forEach((option) => {
      const item = document.createElement('li');
      item.textContent = option.textContent;
      item.dataset.value = option.value;
      if (option.selected) {
        trigger.textContent = option.textContent;
        item.classList.add('is-active');
      }
      item.addEventListener('click', () => setValue(option.value, option.textContent));
      list.appendChild(item);
    });

    if (!trigger.textContent && nativeSelect.options[0]) {
      trigger.textContent = nativeSelect.options[0].textContent;
    }

    trigger.addEventListener('click', () => {
      wrapper.classList.toggle('is-open');
    });

    document.addEventListener('click', (event) => {
      if (!wrapper.contains(event.target)) {
        wrapper.classList.remove('is-open');
      }
    });

    wrapper.appendChild(trigger);
    wrapper.appendChild(list);
    nativeSelect.parentNode.appendChild(wrapper);
  };

  document.querySelectorAll('.ugip-wrapper').forEach((wrapper) => {
    const tabs = [...wrapper.querySelectorAll('.ugip-tab-btn')];
    const panels = [...wrapper.querySelectorAll('.ugip-panel')];

    const nextStepBtn = document.createElement('button');
    nextStepBtn.type = 'button';
    nextStepBtn.className = 'ugip-next-step-btn is-hidden';
    nextStepBtn.textContent = 'مرحله بعدی';
    wrapper.appendChild(nextStepBtn);

    const sellItemsBtn = document.createElement('button');
    sellItemsBtn.type = 'button';
    sellItemsBtn.className = 'ugip-sell-items-btn is-hidden';
    sellItemsBtn.textContent = 'فروش آیتم ها';
    wrapper.appendChild(sellItemsBtn);

    const resultNotice = document.createElement('div');
    resultNotice.className = 'ugip-sell-result is-hidden';
    wrapper.appendChild(resultNotice);

    const getActivePanel = () => panels.find((panel) => panel.classList.contains('is-active')) || panels[0] || null;
    const getSelectedCards = (panel) => [...panel.querySelectorAll('.ugip-card.is-selected')];

    const getAllowedRange = (card) => {
      const basePrice = Number(card.dataset.priceToman || 0);
      const max = Math.max(0, Math.floor(basePrice));
      const min = Math.floor(max * 0.5);
      return { min, max };
    };

    const setInputError = (card, input, message) => {
      const error = card.querySelector('.ugip-custom-price-error');
      input.classList.toggle('is-invalid', Boolean(message));
      input.dataset.invalid = message ? '1' : '0';
      if (error) {
        error.textContent = message || '';
        error.classList.toggle('is-visible', Boolean(message));
      }
    };

    const validateCustomPrice = (card, input) => {
      const { min, max } = getAllowedRange(card);
      const value = Number(input.value || 0);

      if (!input.value) {
        setInputError(card, input, '');
        return false;
      }

      if (value > max) {
        setInputError(card, input, `قیمت نباید بیشتر از ${max.toLocaleString('en-US')} تومان باشد.`);
        return false;
      }

      if (value < min) {
        setInputError(card, input, `قیمت نباید کمتر از ${min.toLocaleString('en-US')} تومان باشد.`);
        return false;
      }

      setInputError(card, input, '');
      return true;
    };

    const selectedCardsArePriced = (panel) => {
      const selected = getSelectedCards(panel);
      if (selected.length === 0 || panel.dataset.selectionLocked !== '1') return false;

      return selected.every((card) => {
        const input = card.querySelector('.ugip-custom-price-input');
        return input && Number(input.value) > 0 && input.dataset.invalid !== '1' && validateCustomPrice(card, input);
      });
    };

    const ensurePriceInputField = (card) => {
      if (card.querySelector('.ugip-custom-price-input')) return;

      const { min, max } = getAllowedRange(card);

      const input = document.createElement('input');
      input.type = 'number';
      input.min = String(min);
      input.max = String(max);
      input.step = '1000';
      input.inputMode = 'numeric';
      input.className = 'ugip-custom-price-input';
      input.placeholder = 'قیمت دلخواه';
      input.dataset.invalid = '0';

      const error = document.createElement('div');
      error.className = 'ugip-custom-price-error';

      input.addEventListener('input', () => {
        validateCustomPrice(card, input);
        updateActionButtons();
      });

      card.appendChild(input);
      card.appendChild(error);
    };

    const updateActionButtons = () => {
      const activePanel = getActivePanel();
      if (!activePanel) {
        nextStepBtn.classList.add('is-hidden');
        sellItemsBtn.classList.add('is-hidden');
        return;
      }

      const selectedCount = getSelectedCards(activePanel).length;
      const isLocked = activePanel.dataset.selectionLocked === '1';
      const canSell = selectedCardsArePriced(activePanel);

      nextStepBtn.classList.toggle('is-hidden', selectedCount === 0 || isLocked);
      sellItemsBtn.classList.toggle('is-hidden', !canSell);
    };

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const game = tab.dataset.game;

        tabs.forEach((btn) => {
          btn.classList.toggle('is-active', btn === tab);
          btn.setAttribute('aria-selected', btn === tab ? 'true' : 'false');
        });

        panels.forEach((panel) => {
          panel.classList.toggle('is-active', panel.dataset.panel === game);
        });

        resultNotice.classList.add('is-hidden');
        updateActionButtons();
      });
    });

    nextStepBtn.addEventListener('click', () => {
      const activePanel = getActivePanel();
      if (!activePanel || activePanel.dataset.selectionLocked === '1') return;

      const cards = [...activePanel.querySelectorAll('.ugip-card')];
      const selectedCards = cards.filter((card) => card.classList.contains('is-selected'));
      if (selectedCards.length === 0) return;

      activePanel.dataset.selectionLocked = '1';

      const filters = activePanel.querySelector('.ugip-filters');
      if (filters) {
        filters.style.display = 'none';
      }

      const loadMoreBtn = activePanel.querySelector('.ugip-load-more-btn');
      if (loadMoreBtn) {
        loadMoreBtn.style.display = 'none';
      }

      cards.forEach((card) => {
        if (!card.classList.contains('is-selected')) {
          card.style.display = 'none';
          return;
        }

        card.style.display = '';
        card.classList.add('is-finalized');
        ensurePriceInputField(card);
      });

      updateActionButtons();
    });

    sellItemsBtn.addEventListener('click', async () => {
      const activePanel = getActivePanel();
      if (!activePanel) return;

      const selectedCards = getSelectedCards(activePanel);
      if (selectedCards.length === 0 || !selectedCardsArePriced(activePanel)) return;

      const items = selectedCards.map((card) => ({
        game: activePanel.dataset.panel || '',
        name: card.dataset.itemName || card.querySelector('h3')?.textContent?.trim() || '',
        custom_price_toman: card.querySelector('.ugip-custom-price-input')?.value || '',
      }));

      sellItemsBtn.disabled = true;
      sellItemsBtn.textContent = 'در حال ثبت...';
      resultNotice.classList.add('is-hidden');

      try {
        const body = new URLSearchParams();
        body.set('action', 'ugip_create_edd_products');
        body.set('nonce', (window.ugipData && window.ugipData.nonce) || '');
        body.set('items', JSON.stringify(items));

        const response = await fetch((window.ugipData && window.ugipData.ajaxUrl) || '/wp-admin/admin-ajax.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          },
          body: body.toString(),
        });

        const result = await response.json();
        const success = result && result.success;

        resultNotice.textContent = success
          ? 'آیتم‌ها با موفقیت به محصولات EDD تبدیل شدند.'
          : ((result && result.data && result.data.message) || 'خطا در تبدیل آیتم‌ها به محصول EDD.');
        resultNotice.classList.toggle('is-error', !success);
        resultNotice.classList.remove('is-hidden');
      } catch (error) {
        resultNotice.textContent = 'ارتباط با سرور برقرار نشد. لطفا دوباره تلاش کنید.';
        resultNotice.classList.add('is-error');
        resultNotice.classList.remove('is-hidden');
      } finally {
        sellItemsBtn.disabled = false;
        sellItemsBtn.textContent = 'فروش آیتم ها';
      }
    });

    panels.forEach((panel) => {
      const grid = panel.querySelector('.ugip-grid');
      if (!grid) return;

      const cards = [...grid.querySelectorAll('.ugip-card')];
      const loadMoreBtn = panel.querySelector('.ugip-load-more-btn');
      const initialVisible = Number(panel.dataset.initialVisible || wrapper.dataset.initialVisible || 24);
      const step = Math.max(8, initialVisible);
      let currentVisible = step;

      const heroFilter = panel.querySelector('.ugip-filter-hero');
      const rarityFilter = panel.querySelector('.ugip-filter-rarity');

      panel.querySelectorAll('.ugip-native-select').forEach(createCustomSelect);

      const filteredCards = () => {
        const selectedHero = heroFilter ? heroFilter.value : '';
        const selectedRarity = rarityFilter ? rarityFilter.value : '';

        return cards.filter((card) => {
          const hero = card.dataset.hero || '';
          const rarity = card.dataset.rarity || '';
          const heroMatch = !selectedHero || hero === selectedHero;
          const rarityMatch = !selectedRarity || rarity === selectedRarity;
          return heroMatch && rarityMatch;
        });
      };

      const renderCards = () => {
        if (panel.dataset.selectionLocked === '1') {
          cards.forEach((card) => {
            card.style.display = card.classList.contains('is-selected') ? '' : 'none';
          });
          if (loadMoreBtn) {
            loadMoreBtn.style.display = 'none';
          }
          updateActionButtons();
          return;
        }

        const matched = filteredCards();

        cards.forEach((card) => {
          card.style.display = 'none';
        });

        matched.slice(0, currentVisible).forEach((card) => {
          card.style.display = '';
        });

        if (loadMoreBtn) {
          loadMoreBtn.style.display = matched.length > currentVisible ? 'inline-flex' : 'none';
        }

        updateActionButtons();
      };

      if (heroFilter) {
        heroFilter.addEventListener('change', () => {
          currentVisible = step;
          renderCards();
        });
      }

      if (rarityFilter) {
        rarityFilter.addEventListener('change', () => {
          currentVisible = step;
          renderCards();
        });
      }

      if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
          currentVisible += step;
          renderCards();
        });
      }

      cards.forEach((card) => {
        card.setAttribute('role', 'button');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-pressed', 'false');

        const toggleSelected = () => {
          if (panel.dataset.selectionLocked === '1') return;
          const isSelected = card.classList.toggle('is-selected');
          card.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
          updateActionButtons();
        };

        card.addEventListener('click', (event) => {
          if (event.target.closest('.ugip-custom-price-input')) return;
          toggleSelected();
        });

        card.addEventListener('keydown', (event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            toggleSelected();
          }
        });
      });

      renderCards();
    });

    updateActionButtons();
  });
});
