<?php
/**
 * Plugin Name: User Game Items Pro
 * Description: Displays connected user inventories for Dota 2, CS2 and TF2 through a shortcode with gaming UI.
 * Version: 1.0.0
 * Author: Custom Dev
 * Text Domain: user-game-items-pro
 */

if (! defined('ABSPATH')) {
    exit;
}

define('UGIP_VERSION', '1.0.0');
define('UGIP_PLUGIN_FILE', __FILE__);
define('UGIP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('UGIP_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once UGIP_PLUGIN_PATH . 'includes/class-ugip-settings.php';
require_once UGIP_PLUGIN_PATH . 'includes/admin/class-ugip-admin-settings-page.php';
require_once UGIP_PLUGIN_PATH . 'includes/class-ugip-inventory-service.php';
require_once UGIP_PLUGIN_PATH . 'includes/class-ugip-shortcode.php';

UGIP_Settings::bootstrap();
UGIP_Admin_Settings_Page::bootstrap();
UGIP_Shortcode::bootstrap();

add_action('wp_enqueue_scripts', static function () {
    wp_register_style(
        'ugip-style',
        UGIP_PLUGIN_URL . 'assets/css/user-game-items.css',
        [],
        UGIP_VERSION
    );

    wp_register_script(
        'ugip-script',
        UGIP_PLUGIN_URL . 'assets/js/user-game-items.js',
        [],
        UGIP_VERSION,
        true
    );
});
