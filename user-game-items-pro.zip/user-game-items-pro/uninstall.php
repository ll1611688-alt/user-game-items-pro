<?php

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('ugip_theme_colors');
delete_option('ugip_cache_hours');
delete_option('ugip_usd_to_toman');
