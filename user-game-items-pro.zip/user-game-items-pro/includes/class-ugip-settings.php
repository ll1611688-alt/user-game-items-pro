<?php

if (! defined('ABSPATH')) {
    exit;
}

class UGIP_Settings {
    public const OPTION_GROUP = 'ugip_settings_group';
    public const OPTION_COLORS = 'ugip_theme_colors';
    public const OPTION_CACHE_HOURS = 'ugip_cache_hours';
    public const OPTION_USD_TO_TOMAN = 'ugip_usd_to_toman';

    public static function bootstrap(): void {
        add_action('admin_init', [self::class, 'register_settings']);
    }

    public static function register_settings(): void {
        register_setting(self::OPTION_GROUP, self::OPTION_COLORS, [
            'type' => 'array',
            'sanitize_callback' => [self::class, 'sanitize_colors'],
            'default' => self::default_colors(),
        ]);

        register_setting(self::OPTION_GROUP, self::OPTION_CACHE_HOURS, [
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 6,
        ]);

        register_setting(self::OPTION_GROUP, self::OPTION_USD_TO_TOMAN, [
            'type' => 'number',
            'sanitize_callback' => [self::class, 'sanitize_usd_rate'],
            'default' => 165000,
        ]);
    }

    public static function sanitize_colors($value): array {
        $defaults = self::default_colors();
        $value = is_array($value) ? $value : [];

        foreach ($defaults as $key => $default) {
            if (! isset($value[$key])) {
                $value[$key] = $default;
            }

            $value[$key] = sanitize_hex_color($value[$key]);
            if (empty($value[$key])) {
                $value[$key] = $default;
            }
        }

        return $value;
    }

    public static function sanitize_usd_rate($value): float {
        $rate = (float) $value;
        return $rate > 0 ? $rate : 165000;
    }

    public static function get_colors(): array {
        $saved = get_option(self::OPTION_COLORS, []);
        return wp_parse_args(is_array($saved) ? $saved : [], self::default_colors());
    }

    public static function default_colors(): array {
        return [
            'primary' => '#7c3aed',
            'secondary' => '#0ea5e9',
            'accent' => '#22c55e',
        ];
    }

    public static function get_cache_hours(): int {
        $hours = (int) get_option(self::OPTION_CACHE_HOURS, 6);
        return max(1, $hours);
    }

    public static function get_usd_to_toman_rate(): float {
        $rate = (float) get_option(self::OPTION_USD_TO_TOMAN, 165000);
        return $rate > 0 ? $rate : 165000;
    }
}
