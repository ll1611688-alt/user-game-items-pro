<?php

if (! defined('ABSPATH')) {
    exit;
}

class UGIP_Shortcode {
    public static function bootstrap(): void {
        add_shortcode('user_game_items', [self::class, 'render']);
        add_action('wp_ajax_ugip_create_edd_products', [self::class, 'create_edd_products']);
    }

    public static function render(array $atts = []): string {
        if (! is_user_logged_in()) {
            return '<div class="ugip-notice">' . esc_html__('Please log in to view your game items.', 'user-game-items-pro') . '</div>';
        }

        $atts = shortcode_atts([
            'limit' => 24,
        ], $atts, 'user_game_items');

        $initial_visible = max(8, min(120, (int) $atts['limit']));
        $user_id = get_current_user_id();
        $steam_id = (string) get_user_meta($user_id, 'steam_id', true);

        if ($steam_id === '') {
            return '<div class="ugip-notice">' . esc_html__('Steam account is not connected for this user.', 'user-game-items-pro') . '</div>';
        }

        wp_enqueue_style('ugip-style');
        wp_enqueue_script('ugip-script');
        wp_localize_script('ugip-script', 'ugipData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ugip_create_edd_products'),
        ]);

        $colors = UGIP_Settings::get_colors();
        $games = UGIP_Inventory_Service::games();

        ob_start();
        ?>
        <section class="ugip-wrapper" style="--ugip-primary: <?php echo esc_attr($colors['primary']); ?>; --ugip-secondary: <?php echo esc_attr($colors['secondary']); ?>; --ugip-accent: <?php echo esc_attr($colors['accent']); ?>;" data-initial-visible="<?php echo esc_attr((string) $initial_visible); ?>">
            <nav class="ugip-tabs" role="tablist" aria-label="<?php esc_attr_e('Game tabs', 'user-game-items-pro'); ?>">
                <?php $first = true; ?>
                <?php foreach ($games as $key => $game) : ?>
                    <button type="button" class="ugip-tab-btn<?php echo $first ? ' is-active' : ''; ?>" data-game="<?php echo esc_attr($key); ?>" role="tab" aria-selected="<?php echo $first ? 'true' : 'false'; ?>">
                        <?php echo esc_html($game['label']); ?>
                    </button>
                    <?php $first = false; ?>
                <?php endforeach; ?>
            </nav>

            <?php $first_panel = true; ?>
            <?php foreach ($games as $game_key => $game) : ?>
                <?php $items = UGIP_Inventory_Service::get_user_items($steam_id, $game_key, 0); ?>
                <div class="ugip-panel<?php echo $first_panel ? ' is-active' : ''; ?>" data-panel="<?php echo esc_attr($game_key); ?>" role="tabpanel" data-initial-visible="<?php echo esc_attr((string) $initial_visible); ?>">
                    <?php if (empty($items)) : ?>
                        <div class="ugip-empty"><?php echo esc_html(sprintf(__('No available items found for %s (inventory may be private).', 'user-game-items-pro'), $game['label'])); ?></div>
                    <?php else : ?>
                        <?php if ($game_key === 'dota2') : ?>
                            <?php
                            $heroes = array_values(array_unique(array_filter(array_map(static function ($item) {
                                return trim((string) ($item['hero'] ?? ''));
                            }, $items))));
                            sort($heroes, SORT_NATURAL | SORT_FLAG_CASE);

                            $rarities = array_values(array_unique(array_filter(array_map(static function ($item) {
                                return trim((string) ($item['rarity'] ?? ''));
                            }, $items))));
                            sort($rarities, SORT_NATURAL | SORT_FLAG_CASE);
                            ?>
                            <div class="ugip-filters" data-filters-for="dota2">
                                <div class="ugip-filter-group">
                                    <label><?php esc_html_e('Hero', 'user-game-items-pro'); ?></label>
                                    <div class="ugip-custom-select-wrap">
                                        <select class="ugip-native-select ugip-filter-hero">
                                            <option value=""><?php esc_html_e('All Heroes', 'user-game-items-pro'); ?></option>
                                            <?php foreach ($heroes as $hero) : ?>
                                                <option value="<?php echo esc_attr(sanitize_title($hero)); ?>"><?php echo esc_html($hero); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="ugip-filter-group">
                                    <label><?php esc_html_e('Rarity', 'user-game-items-pro'); ?></label>
                                    <div class="ugip-custom-select-wrap">
                                        <select class="ugip-native-select ugip-filter-rarity">
                                            <option value=""><?php esc_html_e('All Rarities', 'user-game-items-pro'); ?></option>
                                            <?php foreach ($rarities as $rarity) : ?>
                                                <option value="<?php echo esc_attr(sanitize_title($rarity)); ?>"><?php echo esc_html($rarity); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="ugip-grid">
                            <?php foreach ($items as $item) : ?>
                                <?php
                                $rarity_class = self::rarity_class($item['rarity']);
                                $hero_value = sanitize_title((string) ($item['hero'] ?? ''));
                                $rarity_value = sanitize_title((string) ($item['rarity'] ?? ''));
                                $trade_lock_label = (string) ($item['trade_lock']['label'] ?? '');
                                ?>
                                <article class="ugip-card" data-hero="<?php echo esc_attr($hero_value); ?>" data-rarity="<?php echo esc_attr($rarity_value); ?>" data-item-name="<?php echo esc_attr((string) $item['name']); ?>" data-item-image="<?php echo esc_url((string) ($item['image'] ?? '')); ?>" data-price-toman="<?php echo esc_attr((string) ((float) ($item['price_toman'] ?? 0))); ?>">
                                    <div class="ugip-image-wrap">
                                        <?php if (! empty($trade_lock_label)) : ?>
                                            <span class="ugip-tradelock-badge"><?php echo esc_html($trade_lock_label); ?></span>
                                        <?php endif; ?>
                                        <?php if (! empty($item['image'])) : ?>
                                            <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['name']); ?>" loading="lazy" />
                                        <?php else : ?>
                                            <div class="ugip-image-fallback"><?php esc_html_e('No Image', 'user-game-items-pro'); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ugip-content">
                                        <h3><?php echo esc_html($item['name']); ?></h3>
                                        <div class="ugip-meta-badges">
                                            <?php if ($game_key === 'dota2') : ?>
                                                <span class="ugip-pill ugip-pill-hero"><?php echo esc_html($item['hero'] ?: __('Unknown Hero', 'user-game-items-pro')); ?></span>
                                            <?php endif; ?>
                                            <span class="ugip-pill ugip-pill-rarity <?php echo esc_attr($rarity_class); ?>"><?php echo esc_html($item['rarity']); ?></span>
                                        </div>
                                    </div>
                                    <footer class="ugip-pricing">
                                        <span><?php echo esc_html('$' . number_format_i18n((float) $item['price_usd'], 2)); ?></span>
                                        <span><?php echo esc_html(number_format_i18n((float) $item['price_toman'], 0) . ' تومان'); ?></span>
                                    </footer>
                                </article>
                            <?php endforeach; ?>
                        </div>

                        <div class="ugip-load-more-wrap">
                            <button type="button" class="ugip-load-more-btn"><?php esc_html_e('بارگذاری بیشتر', 'user-game-items-pro'); ?></button>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $first_panel = false; ?>
            <?php endforeach; ?>
        </section>
        <?php

        return (string) ob_get_clean();
    }


    public static function create_edd_products(): void {
        if (! is_user_logged_in()) {
            wp_send_json_error(['message' => __('Login required.', 'user-game-items-pro')], 401);
        }

        check_ajax_referer('ugip_create_edd_products', 'nonce');

        if (! post_type_exists('download')) {
            wp_send_json_error(['message' => __('Easy Digital Downloads is not active.', 'user-game-items-pro')], 400);
        }

        $raw_items = wp_unslash($_POST['items'] ?? []);
        if (is_string($raw_items)) {
            $decoded = json_decode($raw_items, true);
            $raw_items = is_array($decoded) ? $decoded : [];
        }

        if (! is_array($raw_items) || empty($raw_items)) {
            wp_send_json_error(['message' => __('No items received.', 'user-game-items-pro')], 400);
        }

        $category_map = [
            'dota2' => 'Dota 2 Items',
            'cs2' => 'Cs2 Items',
            'tf2' => 'Tf2 Items',
        ];

        $created = [];

        foreach ($raw_items as $raw_item) {
            if (! is_array($raw_item)) {
                continue;
            }

            $game = sanitize_key((string) ($raw_item['game'] ?? ''));
            $name = sanitize_text_field((string) ($raw_item['name'] ?? ''));
            $custom_price = (float) preg_replace('/[^0-9.]/', '', (string) ($raw_item['custom_price_toman'] ?? '0'));

            if ($name === '' || $custom_price <= 0 || ! isset($category_map[$game])) {
                continue;
            }

            $post_id = wp_insert_post([
                'post_type' => 'download',
                'post_status' => 'publish',
                'post_title' => $name,
                'post_content' => '',
            ], true);

            if (is_wp_error($post_id)) {
                continue;
            }

            update_post_meta($post_id, 'edd_price', $custom_price);

            $term_name = $category_map[$game];
            $term = term_exists($term_name, 'download_category');
            if (! $term) {
                $term = wp_insert_term($term_name, 'download_category');
            }

            if (is_array($term) && isset($term['term_id'])) {
                wp_set_object_terms($post_id, [(int) $term['term_id']], 'download_category', false);
            }

            $created[] = $post_id;
        }

        if (empty($created)) {
            wp_send_json_error(['message' => __('No products were created. Please check entered prices.', 'user-game-items-pro')], 400);
        }

        wp_send_json_success([
            'message' => __('Items converted to EDD products successfully.', 'user-game-items-pro'),
            'count' => count($created),
            'ids' => $created,
        ]);
    }

    private static function rarity_class(string $rarity): string {
        $normalized = sanitize_title($rarity);

        $map = [
            'consumer-grade' => 'is-consumer',
            'base-grade' => 'is-base',
            'common' => 'is-common',
            'industrial-grade' => 'is-industrial',
            'uncommon' => 'is-uncommon',
            'mil-spec-grade' => 'is-milspec',
            'rare' => 'is-rare',
            'restricted' => 'is-restricted',
            'mythical' => 'is-mythical',
            'classified' => 'is-classified',
            'legendary' => 'is-legendary',
            'immortal' => 'is-immortal',
            'covert' => 'is-covert',
            'arcana' => 'is-arcana',
            'ancient' => 'is-ancient',
            'contraband' => 'is-contraband',
        ];

        return $map[$normalized] ?? 'is-unknown';
    }
}
