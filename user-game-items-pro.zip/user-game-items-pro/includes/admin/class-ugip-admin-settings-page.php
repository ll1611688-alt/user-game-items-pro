<?php

if (! defined('ABSPATH')) {
    exit;
}

class UGIP_Admin_Settings_Page {
    public static function bootstrap(): void {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_post_ugip_clear_cache', [self::class, 'handle_clear_cache']);
    }

    public static function register_menu(): void {
        add_options_page(
            __('User Game Items Pro', 'user-game-items-pro'),
            __('User Game Items Pro', 'user-game-items-pro'),
            'manage_options',
            'ugip-settings',
            [self::class, 'render_settings_page']
        );
    }

    public static function render_settings_page(): void {
        if (! current_user_can('manage_options')) {
            return;
        }

        $colors = UGIP_Settings::get_colors();
        $cache_hours = UGIP_Settings::get_cache_hours();
        $usd_rate = UGIP_Settings::get_usd_to_toman_rate();
        $cache_cleared = isset($_GET['ugip_cache_cleared']) && sanitize_text_field(wp_unslash($_GET['ugip_cache_cleared'])) === '1';
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('User Game Items Pro Settings', 'user-game-items-pro'); ?></h1>

            <?php if ($cache_cleared) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Plugin cache cleared successfully.', 'user-game-items-pro'); ?></p></div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields(UGIP_Settings::OPTION_GROUP); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Primary Color', 'user-game-items-pro'); ?></th>
                        <td><input type="color" name="<?php echo esc_attr(UGIP_Settings::OPTION_COLORS); ?>[primary]" value="<?php echo esc_attr($colors['primary']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Secondary Color', 'user-game-items-pro'); ?></th>
                        <td><input type="color" name="<?php echo esc_attr(UGIP_Settings::OPTION_COLORS); ?>[secondary]" value="<?php echo esc_attr($colors['secondary']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Accent Color', 'user-game-items-pro'); ?></th>
                        <td><input type="color" name="<?php echo esc_attr(UGIP_Settings::OPTION_COLORS); ?>[accent]" value="<?php echo esc_attr($colors['accent']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ugip_cache_hours"><?php esc_html_e('Inventory Cache (hours)', 'user-game-items-pro'); ?></label></th>
                        <td>
                            <input id="ugip_cache_hours" type="number" min="1" max="48" name="<?php echo esc_attr(UGIP_Settings::OPTION_CACHE_HOURS); ?>" value="<?php echo esc_attr((string) $cache_hours); ?>" />
                            <p class="description"><?php esc_html_e('Used for inventory and market price cache.', 'user-game-items-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ugip_usd_to_toman"><?php esc_html_e('USD to Toman Rate (for 1 USD)', 'user-game-items-pro'); ?></label></th>
                        <td>
                            <input id="ugip_usd_to_toman" type="number" min="1" step="0.01" name="<?php echo esc_attr(UGIP_Settings::OPTION_USD_TO_TOMAN); ?>" value="<?php echo esc_attr((string) $usd_rate); ?>" />
                            <p class="description"><?php esc_html_e('Example: 165000 means 1 USD = 165000 Toman.', 'user-game-items-pro'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr />

            <h2><?php esc_html_e('Cache Management', 'user-game-items-pro'); ?></h2>
            <p><?php esc_html_e('If you changed cache duration or need fresh Steam data, clear all plugin transients.', 'user-game-items-pro'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ugip_clear_cache" />
                <?php wp_nonce_field('ugip_clear_cache_action', 'ugip_clear_cache_nonce'); ?>
                <?php submit_button(__('Clear Plugin Cache', 'user-game-items-pro'), 'delete', 'submit', false); ?>
            </form>
        </div>
        <?php
    }

    public static function handle_clear_cache(): void {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'user-game-items-pro'));
        }

        check_admin_referer('ugip_clear_cache_action', 'ugip_clear_cache_nonce');
        self::clear_plugin_transients();

        $redirect_url = add_query_arg('ugip_cache_cleared', '1', admin_url('options-general.php?page=ugip-settings'));
        wp_safe_redirect($redirect_url);
        exit;
    }

    public static function clear_plugin_transients(): void {
        global $wpdb;

        $option_table = $wpdb->options;
        $like_main = $wpdb->esc_like('_transient_ugip_') . '%';
        $like_timeout = $wpdb->esc_like('_transient_timeout_ugip_') . '%';

        $wpdb->query($wpdb->prepare("DELETE FROM {$option_table} WHERE option_name LIKE %s", $like_main));
        $wpdb->query($wpdb->prepare("DELETE FROM {$option_table} WHERE option_name LIKE %s", $like_timeout));
    }
}
