<?php

if (! defined('ABSPATH')) {
    exit;
}

class UGIP_Inventory_Service {
    /**
     * @return array<string,array<string,mixed>>
     */
    public static function games(): array {
        return [
            'dota2' => [
                'label' => 'Dota 2',
                'appid' => 570,
                'contextid' => 2,
            ],
            'cs2' => [
                'label' => 'CS2',
                'appid' => 730,
                'contextid' => 2,
            ],
            'tf2' => [
                'label' => 'TF2',
                'appid' => 440,
                'contextid' => 2,
            ],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    public static function get_user_items(string $steam_id, string $game_key, int $max_items = 0): array {
        $games = self::games();
        if (! isset($games[$game_key]) || empty($steam_id)) {
            return [];
        }

        $game = $games[$game_key];
        $cache_key = sprintf('ugip_inv_%s_%s_%d', $game_key, $steam_id, $max_items);
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return $cached;
        }

        $payload = self::fetch_inventory_payload($steam_id, (int) $game['appid'], (int) $game['contextid']);
        if (! is_array($payload) || empty($payload['assets']) || empty($payload['descriptions'])) {
            return [];
        }

        $desc_map = [];
        foreach ($payload['descriptions'] as $desc) {
            if (! isset($desc['classid'], $desc['instanceid'])) {
                continue;
            }

            $desc_key = $desc['classid'] . '_' . $desc['instanceid'];
            $desc_map[$desc_key] = $desc;
        }

        $items = [];
        $unique_price_cache = [];

        foreach ($payload['assets'] as $asset) {
            $desc_key = ($asset['classid'] ?? '') . '_' . ($asset['instanceid'] ?? '');
            if (! isset($desc_map[$desc_key])) {
                continue;
            }

            $desc = $desc_map[$desc_key];
            $market_name = (string) ($desc['market_hash_name'] ?? $desc['name'] ?? 'Unknown Item');

            if (! isset($unique_price_cache[$market_name])) {
                $unique_price_cache[$market_name] = self::get_item_price_usd((int) $game['appid'], $market_name);
            }

            $price_usd = $unique_price_cache[$market_name];

            $items[] = [
                'name' => (string) ($desc['name'] ?? 'Unknown Item'),
                'hero' => $game_key === 'dota2' ? self::extract_hero_name($desc) : '',
                'rarity' => self::extract_rarity($desc),
                'image' => self::build_image_url($desc),
                'price_usd' => $price_usd,
                'price_toman' => $price_usd * UGIP_Settings::get_usd_to_toman_rate(),
                'trade_lock' => self::extract_trade_lock($desc),
            ];
        }

        usort($items, static function (array $a, array $b): int {
            return $b['price_usd'] <=> $a['price_usd'];
        });

        if ($max_items > 0 && count($items) > $max_items) {
            $items = array_slice($items, 0, $max_items);
        }

        set_transient($cache_key, $items, UGIP_Settings::get_cache_hours() * HOUR_IN_SECONDS);
        return $items;
    }


    /**
     * Steam Inventory has practical limits for `count`; large values can return non-200/empty payloads.
     * Try a safe page size first and then fallback to smaller one.
     *
     * @return array<string,mixed>|null
     */
    private static function fetch_inventory_payload(string $steam_id, int $appid, int $contextid): ?array {
        $counts = [2000, 500, 120];

        foreach ($counts as $count) {
            $url = sprintf(
                'https://steamcommunity.com/inventory/%s/%d/%d?l=english&count=%d',
                rawurlencode($steam_id),
                $appid,
                $contextid,
                $count
            );

            $response = wp_remote_get($url, [
                'timeout' => 20,
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url('/'),
                ],
            ]);

            if (is_wp_error($response)) {
                continue;
            }

            $code = (int) wp_remote_retrieve_response_code($response);
            if ($code < 200 || $code >= 300) {
                continue;
            }

            $payload = json_decode((string) wp_remote_retrieve_body($response), true);
            if (! is_array($payload)) {
                continue;
            }

            if (! empty($payload['assets']) && ! empty($payload['descriptions'])) {
                return $payload;
            }
        }

        return null;
    }

    private static function build_image_url(array $desc): string {
        $icon = (string) ($desc['icon_url_large'] ?? $desc['icon_url'] ?? '');
        if ($icon === '') {
            return '';
        }

        return 'https://community.cloudflare.steamstatic.com/economy/image/' . ltrim($icon, '/');
    }

    private static function extract_rarity(array $desc): string {
        if (empty($desc['tags']) || ! is_array($desc['tags'])) {
            return __('Unknown', 'user-game-items-pro');
        }

        foreach ($desc['tags'] as $tag) {
            $category = (string) ($tag['category'] ?? '');
            if (stripos($category, 'Rarity') !== false) {
                return (string) ($tag['localized_tag_name'] ?? $tag['name'] ?? __('Unknown', 'user-game-items-pro'));
            }
        }

        return __('Unknown', 'user-game-items-pro');
    }

    private static function extract_hero_name(array $desc): string {
        if (empty($desc['tags']) || ! is_array($desc['tags'])) {
            return '';
        }

        foreach ($desc['tags'] as $tag) {
            $category = (string) ($tag['category'] ?? '');
            if (stripos($category, 'Hero') !== false) {
                return (string) ($tag['localized_tag_name'] ?? $tag['name'] ?? '');
            }
        }

        return '';
    }

    /**
     * @return array<string,mixed>
     */
    private static function extract_trade_lock(array $desc): array {
        $texts = [];

        foreach (['owner_descriptions', 'descriptions'] as $key) {
            if (! empty($desc[$key]) && is_array($desc[$key])) {
                foreach ($desc[$key] as $part) {
                    if (! empty($part['value'])) {
                        $texts[] = wp_strip_all_tags((string) $part['value']);
                    }
                }
            }
        }

        foreach ($texts as $text) {
            if (stripos($text, 'Tradable After') === false) {
                continue;
            }

            $date_candidate = trim((string) preg_replace('/^.*Tradable After\s*/i', '', $text));
            $timestamp = strtotime($date_candidate);

            if ($timestamp && $timestamp > time()) {
                $remaining = $timestamp - time();

                return [
                    'seconds' => $remaining,
                    'label' => self::format_remaining_time($remaining),
                ];
            }
        }

        return [
            'seconds' => 0,
            'label' => '',
        ];
    }

    private static function format_remaining_time(int $seconds): string {
        if ($seconds <= 0) {
            return '';
        }

        $days = (int) floor($seconds / DAY_IN_SECONDS);
        if ($days > 0) {
            return sprintf(_n('%d day left', '%d days left', $days, 'user-game-items-pro'), $days);
        }

        $hours = (int) floor($seconds / HOUR_IN_SECONDS);
        if ($hours > 0) {
            return sprintf(_n('%d hour left', '%d hours left', $hours, 'user-game-items-pro'), $hours);
        }

        $minutes = max(1, (int) floor($seconds / MINUTE_IN_SECONDS));
        return sprintf(_n('%d minute left', '%d minutes left', $minutes, 'user-game-items-pro'), $minutes);
    }

    private static function get_item_price_usd(int $appid, string $market_hash_name): float {
        $market_hash_name = trim($market_hash_name);
        if ($market_hash_name === '') {
            return 0.0;
        }

        $key = 'ugip_price_' . md5($appid . ':' . $market_hash_name);
        $cached = get_transient($key);
        if ($cached !== false) {
            return (float) $cached;
        }

        $url = add_query_arg([
            'currency' => 1,
            'appid' => $appid,
            'market_hash_name' => $market_hash_name,
        ], 'https://steamcommunity.com/market/priceoverview/');

        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            set_transient($key, 0, 2 * HOUR_IN_SECONDS);
            return 0.0;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            set_transient($key, 0, 2 * HOUR_IN_SECONDS);
            return 0.0;
        }

        $payload = json_decode((string) wp_remote_retrieve_body($response), true);
        $price = isset($payload['lowest_price']) ? self::parse_price_string((string) $payload['lowest_price']) : 0.0;

        set_transient($key, $price, UGIP_Settings::get_cache_hours() * HOUR_IN_SECONDS);
        return $price;
    }

    private static function parse_price_string(string $price_string): float {
        if ($price_string === '') {
            return 0.0;
        }

        $normalized = preg_replace('/[^0-9.,]/', '', $price_string);
        if ($normalized === null || $normalized === '') {
            return 0.0;
        }

        if (substr_count($normalized, ',') > 0 && substr_count($normalized, '.') === 0) {
            $normalized = str_replace(',', '.', $normalized);
        } else {
            $normalized = str_replace(',', '', $normalized);
        }

        return (float) $normalized;
    }
}
